namespace foo {
    enum Bar { Tag1, Tag2 };
    static void f( Bar b ) { printf( "b = %d\n", (int)b ); }
}

